% Chetty Data and I(1), I(0), etc. tests

clear all;
small = 1.0e-10;
big = 1.0e+8;
global datadir;

% -- File Directories   
outdir = 'out/';
figdir = 'fig/';
matdir = 'mat/';
dataxls = '../Data/Chetty_Mobility/Chetty_Data_1.xlsx';
addpath('../matlab_functions');

%%
q = 15;
% --- Confidence interval grid 
n_rho1 = 100;
rho_grid = linspace(0,0.999,n_rho1)';
n_rho2 = 50;
rho_grid_ha = linspace(0,0.999,n_rho2)';
n_rho_grid = length(rho_grid);
% --- Random numbers to use for all simulations
nrep = 100000;
emat = randn(q,nrep);
%% 
% Read Data
T = readtable(dataxls);
CZ = T{:,'CZ'};
LatLon = [T{:,'Lat'} T{:,'Lon'}];
VariableNames=T.Properties.VariableNames;
% Variables to Save
rslt_mat = NaN(46,3);
plot_rslt_mat = NaN(n_rho_grid,5,46);

for ivar = 7:46
    VarName = char(VariableNames(ivar));
    Y = T{:,ivar};
    ii = isnan(Y);
    Y = Y(ii==0);
    s = LatLon(ii==0,:);
    n = length(s);
    latlongflag = 1;
    distmat = getdistmat(s,latlongflag);

    % I1 and I0 Tests
    SP_I1 = Spatial_I1_Test(Y,distmat,emat);
    SP_I0 = Spatial_I0_Test(Y,distmat,emat);
    ivar
    [SP_I0.pvalue SP_I1.pvalue]
    rslt_mat(ivar,1)=n;
    rslt_mat(ivar,2)=SP_I0.pvalue;
    rslt_mat(ivar,3)=SP_I1.pvalue;

    plotrslt=c_ci_plot(Y,distmat,emat,rho_grid,rho_grid_ha);
    plot_rslt_mat(:,:,ivar)=plotrslt;
end

% Save Results for future processing
save('rslt_mat','rslt_mat');
save('plot_rslt_mat','plot_rslt_mat');
save('rho_grid','rho_grid');











    

