% Chetty Data and I(1), I(0), etc. tests

clear all;
small = 1.0e-10;
big = 1.0e+8;
global datadir;

% -- File Directories   
outdir = 'out/';
figdir = 'fig/';
matdir = 'mat/';
addpath('../matlab_functions');

% Read Data
dataxls = '../Data/Chetty_Mobility/Chetty_Data_Labels.xlsx';
[~,tmp] = xlsread(dataxls,'A2:AT2');
VariableDesc = tmp';
dataxls = '../Data/Chetty_Mobility/Chetty_Data_1.xlsx';
T = readtable(dataxls);
CZ = T{:,'CZ'};
LatLon = [T{:,'Lat'} T{:,'Lon'}];
VariableNames=T.Properties.VariableNames;

% Load Results from Chetty_i1_tests_all
load('rslt_mat');
load('plot_rslt_mat');
load('rho_grid');
n_series = size(rslt_mat,1);
% Save as CSV File
outfile_name = [outdir 'Chetty_SP_Pvalues.csv'];
fileID = fopen(outfile_name,'w');
fprintf(fileID,'Name, Desc, n, I(0) pvalue, I(1) pvalue, CI_lower, CI_upper \n');
for i = 1: n_series
    if isnan(rslt_mat(i,2)) == 0
        str1 = [char(VariableNames(i)) ',' char(VariableDesc(i))];
        tmp = rslt_mat(i,:);
        plot_rslt = squeeze(plot_rslt_mat(:,:,i));
        pv = plot_rslt(:,2);
        ii = pv > 0.05;
        rh = rho_grid(ii==1);
        ci_l = min(rh);
        ci_u = max(rh);
        tmp = [tmp ci_l ci_u];
        fprintf(fileID,[str1 ', %3i, %6.4f , %6.4f, %5.2f, %5.2f \n'],tmp);
    end
end

% Repeat for 9 variables
var_ind = [7 13 14 16 18 19 20 21 27 28 29 40 41 42 43 44 45 24 30 31 32 34 35 36 37 38 39];


% Save as CSV File
outfile_name = [outdir 'Chetty_SP_Pvalues_27Variables.csv'];
fileID = fopen(outfile_name,'w');
fprintf(fileID,'Name, Desc, n, I(0) pvalue, I(1) pvalue, [CI] \n');
for ii = 1:length(var_ind);
        i = var_ind(ii);
        str1 = [char(VariableNames(i)) ',' char(VariableDesc(i))];
        tmp = rslt_mat(i,:);
        plot_rslt = squeeze(plot_rslt_mat(:,:,i));
        pv = plot_rslt(:,2);
        ii = pv > 0.05;
        rh = rho_grid(ii==1);
        ci_l = min(rh);
        ci_u = max(rh);
        tmp = [tmp ci_l ci_u];
        fprintf(fileID,[str1 ', %3i, %6.2f, %6.2f, [%5.2f;%5.2f] \n'],tmp);
end


    

