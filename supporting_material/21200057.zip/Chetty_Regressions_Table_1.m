% Chetty Data and I(1), I(0), etc. tests

clear all;
small = 1.0e-10;
big = 1.0e+8;
global datadir;

% -- File Directories   
outdir = 'out/';
figdir = 'fig/';
matdir = 'mat/';
dataxls = '../Data/Chetty_Mobility/Chetty_Data_1.xlsx';
addpath('../matlab_functions');
addpath('../cscpc')

%% 
% Read Data
dataxls = '../Data/Chetty_Mobility/Chetty_Data_Labels.xlsx';
[~,tmp] = xlsread(dataxls,'A2:AT2');
VariableDesc = tmp';
dataxls = '../Data/Chetty_Mobility/Chetty_Data_1.xlsx';
T = readtable(dataxls);
CZ = T{:,'CZ'};
LatLon = [T{:,'Lat'} T{:,'Lon'}];
VariableNames=T.Properties.VariableNames;
State = T{:,'State'};
[Su,ia,state_id]=unique(State);


% Repeat for 8 variables
y_ind = 7;
x_ind = [13 14 16 18 19 20 21 27 28 29 40 41 42 43 44 45 24 30 31 32 34 35 36 37 38 39];

i = y_ind;
y_str1 = [char(VariableNames(i))];
y_raw = T{:,i};
n_xind = length(x_ind);


Results_OLS = NaN(n_xind,3);
Results_FGLS_CSCPC = NaN(n_xind,3);


for ix = 1:n_xind
i = x_ind(ix);
x_str1 = [char(VariableNames(i))];
x_raw = T{:,i};
iiy = 1-isnan(y_raw);
iix = 1-isnan(x_raw);
ii = iiy.*iix;

y = y_raw(ii==1);
x = x_raw(ii==1);
s = LatLon(ii==1,:);
sid = state_id(ii==1,:);
n = length(s);
latlongflag = 1;
distmat = getdistmat(s,latlongflag);

% Standardize 
ys = (y-mean(y))/std(y);
xs = (x-mean(x))/std(x);

% xs = x-mean(x);
% ys = y-mean(y);

[b,seb,veb]=ols_clustered_se(xs,ys,sid);

% Construct LBM Covariance matrix
% BM covariance matrix (approximation for demeanded value)
rho_bm = 0.999;
c_bm = getcbar(rho_bm,distmat);
sigdm_bm = get_sigma_dm(distmat,c_bm);
% Construct GLS Transformation
[V,D]=eig(sigdm_bm);
D1 = real(diag(sqrt(1./diag(D))));
V = real(V);
H = D1*V';
hy = H*ys;
hx = H*xs;
hy = hy-mean(hy);
hx = hx-mean(hx);
rhobar = 0.03;
ci_level = 0.95;
rslt = cscpc(hy,hx,s,latlongflag,rhobar,ci_level);  % Run CSCPC
Results_OLS(ix,:) = [b b-1.96*seb b+1.96*seb];
Results_FGLS_CSCPC(ix,:) = [rslt.beta_hat rslt.ci_cscpc];

end

% [Results_OLS Results_FGLS_CSCPC]

% Save as CSV File
outfile_name = [outdir 'Chetty_Regression_27Variables_Table1.csv'];
fileID = fopen(outfile_name,'w');
fprintf(fileID,'Name, Desc, OLS (Clust SE), FGLS(CSCPC) \n');
for ii = 1:length(x_ind);
        i = x_ind(ii);
        str1 = [char(VariableNames(i)) ',' char(VariableDesc(i))];
        tmp = [Results_OLS(ii,:) Results_FGLS_CSCPC(ii,:)];
        fprintf(fileID,[str1 ', %5.2f [%5.2f;%5.2f], %5.2f [%5.2f;%5.2f] \n'],tmp);
end


% ----------- Functions -------------
function [b,seb,veb]=ols_clustered_se(x,y,cluster_var)
% Clustered SEs for y on x regression
% c_ind is the cluster index
b = x\y;
e = y-x*b;
[c,~,ind]=unique(cluster_var);
ncluster = length(c);
n = size(x,1);
k = size(x,2);
xe_xe = zeros(k,k);
for i = 1:ncluster
    xc = x(ind==i,:);
    ec = e(ind==i);
    ac = xc'*ec;
    xe_xe = xe_xe+ac*ac';
end
xx = x'*x;
xxi = inv(xx);
V = xxi*xe_xe*xxi;
q = ((n-1)/(n-k))*(ncluster/(ncluster-1));
V = q*V;
veb = V;
seb = sqrt(diag(veb));

end








    

